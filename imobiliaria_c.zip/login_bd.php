<?php 

$vServidor="localhost";
$vUsuario="root";
$vSenha="16099515";
$vBaseDados="teste";

?>
